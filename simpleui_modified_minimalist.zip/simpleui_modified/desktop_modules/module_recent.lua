-- module_recent.lua — Simple UI
-- Módulo: Recent Books.
-- Substitui a parte "recent" de recentbookswidget.lua.

local Blitbuffer      = require("ffi/blitbuffer")
local Device          = require("device")
local Font            = require("ui/font")
local FrameContainer  = require("ui/widget/container/framecontainer")
local Geom            = require("ui/geometry")
local GestureRange    = require("ui/gesturerange")
local UIManager       = require("ui/uimanager")
local HorizontalGroup = require("ui/widget/horizontalgroup")
local HorizontalSpan  = require("ui/widget/horizontalspan")
local InputContainer  = require("ui/widget/container/inputcontainer")
local LineWidget      = require("ui/widget/linewidget")
local OverlapGroup    = require("ui/widget/overlapgroup")
local CenterContainer = require("ui/widget/container/centercontainer")
local TextWidget      = require("ui/widget/textwidget")
local VerticalGroup   = require("ui/widget/verticalgroup")
local Screen          = Device.screen
local _ = require("sui_i18n").translate

local logger  = require("logger")
local _SH = nil
local function getSH()
    if not _SH then
        local ok, m = pcall(require, "desktop_modules/module_books_shared")
        if ok and m then _SH = m
        else logger.warn("simpleui: module_recent: cannot load module_books_shared: " .. tostring(m)) end
    end
    return _SH
end

local Config       = require("sui_config")
local UI           = require("sui_core")
local Bottombar    = require("sui_bottombar")
local PAD          = UI.PAD
local PAD2         = UI.PAD2
local MOD_GAP      = UI.MOD_GAP
local LABEL_H      = UI.LABEL_H
local CLR_TEXT_SUB = UI.CLR_TEXT_SUB

local _BASE_RB_PCT_FS = Screen:scaleBySize(8)  -- "XX% Read" label font size — base value

local SETTING_PROGRESS      = "recent_show_progress"  -- pfx .. this; default ON
local SETTING_TEXT          = "recent_show_text"       -- pfx .. this; default ON
local SETTING_OVERLAY       = "recent_show_overlay"    -- pfx .. this; default OFF
local SETTING_SHOW_FINISHED = "recent_show_finished"   -- pfx .. this; default OFF

local function showProgress(pfx)
    return G_reader_settings:readSetting(pfx .. SETTING_PROGRESS) ~= false
end
local function showText(pfx)
    return G_reader_settings:readSetting(pfx .. SETTING_TEXT) ~= false
end
local function showOverlay(pfx)
    return G_reader_settings:readSetting(pfx .. SETTING_OVERLAY) == true
end
local function showFinished(pfx)
    return G_reader_settings:readSetting(pfx .. SETTING_SHOW_FINISHED) == true
end


local M = {}

M.id          = "recent"
M.name        = _("Recent Books")
M.label       = _("Recent Books")
M.enabled_key = "recent"
M.default_on  = true

-- Called by teardown (via _PLUGIN_MODULES flush) to drop the cached reference
-- to module_books_shared so a hot update picks up fresh code on next load.
function M.reset() _SH = nil end

function M.build(w, ctx)
    Config.applyLabelToggle(M, _("Recent Books"))
    if not ctx.recent_fps or #ctx.recent_fps == 0 then return nil end

    local SH          = getSH()
    local scale       = Config.getModuleScale("recent", ctx.pfx)
    local lbl_scale   = Config.getItemLabelScale("recent", ctx.pfx)
    local pct_fs      = math.max(8, math.floor(_BASE_RB_PCT_FS * scale * lbl_scale))
    local pct_face    = Font:getFace("smallinfofont", pct_fs)


    -- 3 columns × 2 rows = 6 books per page, up to 18 total (3 pages of 6).
    -- Swipe left/right to move between pages.
    local COLS      = 3
    local ROWS      = 2
    local PER_PAGE  = COLS * ROWS  -- 6
    local MAX_BOOKS = 18
    local total     = math.min(#ctx.recent_fps, MAX_BOOKS)
    -- Gap between covers: 1.5× the original 6px gap = 9px
    local gap     = Screen:scaleBySize(9)
    local inner_w = w - PAD * 2
    -- Cover width: 3 columns with 2 gaps between them
    local cw      = math.floor((inner_w - gap * (COLS - 1)) / COLS)
    -- Cover height: portrait ratio 2:3
    local ch      = math.floor(cw * 1.5)
    local row_gap = gap
    local cell_h  = ch

    local use_overlay = showOverlay(ctx.pfx)

    -- Current page stored in ctx so swipes can update it.
    if not ctx._recent_page then ctx._recent_page = 1 end
    local max_pages = math.max(1, math.ceil(total / PER_PAGE))
    -- Clamp page in case books were removed.
    if ctx._recent_page > max_pages then ctx._recent_page = max_pages end
    local page      = ctx._recent_page
    local page_start = (page - 1) * PER_PAGE + 1
    local page_end   = math.min(page_start + PER_PAGE - 1, total)

    local function buildCell(i, fp)
        local bd    = SH.getBookData(fp, ctx.prefetched and ctx.prefetched[fp])
        local raw_cover = SH.getBookCover(fp, cw, ch, nil, 0.10)
                       or SH.coverPlaceholder(bd.title, cw, ch)

        -- Always wrap in a FrameContainer with explicit dimen so paintTo never
        -- receives a nil size — this is what prevents the framecontainer crash.
        local cover = FrameContainer:new{
            bordersize = 0,
            padding    = 0,
            dimen      = Geom:new{ w = cw, h = ch },
            raw_cover,
        }

        local cover_widget = cover

        if use_overlay then
            local badge_r = math.floor(cw * 0.20)
            local badge_d = badge_r * 2
            local pct_int = math.floor((bd.percent or 0) * 100)
            local badge = FrameContainer:new{
                bordersize  = 0,
                background  = Blitbuffer.gray(0.15),
                padding     = 0,
                dimen       = Geom:new{ w = badge_d, h = badge_d },
                radius      = badge_r,
                CenterContainer:new{
                    dimen = Geom:new{ w = badge_d, h = badge_d },
                    TextWidget:new{
                        text    = string.format(_("%d%%"), pct_int),
                        face    = pct_face,
                        bold    = true,
                        fgcolor = Blitbuffer.COLOR_BLACK,
                    },
                },
            }
            badge.overlap_offset = { math.floor((cw - badge_d) / 2), ch - badge_r }
            cover_widget = OverlapGroup:new{
                dimen = Geom:new{ w = cw, h = ch + badge_r },
                cover, badge,
            }
        end

        local tappable = InputContainer:new{
            dimen    = Geom:new{ w = cw, h = cell_h },
            [1]      = VerticalGroup:new{ align = "center", cover_widget },
            _fp      = fp,
            _open_fn = ctx.open_fn,
        }
        tappable.ges_events = {
            TapBook = {
                GestureRange:new{
                    ges   = "tap",
                    range = function() return tappable.dimen end,
                },
            },
        }
        function tappable:onTapBook()
            if self._open_fn then self._open_fn(self._fp) end
            return true
        end

        if ctx.kb_recent_focus_idx == i then
            local bw = Screen:scaleBySize(3)
            return OverlapGroup:new{
                dimen = Geom:new{ w = cw, h = cell_h },
                tappable,
                LineWidget:new{ dimen = Geom:new{ w = cw, h = bw },    background = Blitbuffer.COLOR_BLACK },
                LineWidget:new{ dimen = Geom:new{ w = cw, h = bw },    background = Blitbuffer.COLOR_BLACK, overlap_offset = {0, cell_h - bw} },
                LineWidget:new{ dimen = Geom:new{ w = bw, h = cell_h }, background = Blitbuffer.COLOR_BLACK },
                LineWidget:new{ dimen = Geom:new{ w = bw, h = cell_h }, background = Blitbuffer.COLOR_BLACK, overlap_offset = {cw - bw, 0} },
            }
        end
        return tappable
    end

    -- Build the current page as a 2-column grid.
    local grid    = VerticalGroup:new{ align = "left" }
    local col     = 0
    local row_h   = nil
    local cur_row = nil
    for i = page_start, page_end do
        if col == 0 then
            cur_row = HorizontalGroup:new{ align = "top" }
            if #grid > 0 then grid[#grid+1] = SH.vspan(row_gap, ctx.vspan_pool) end
            grid[#grid+1] = cur_row
        else
            cur_row[#cur_row+1] = HorizontalSpan:new{ width = gap }
        end
        cur_row[#cur_row+1] = buildCell(i, ctx.recent_fps[i])
        col = (col + 1) % COLS
    end

    -- Page indicator circles (only shown when there are multiple pages).
    local indicator = nil
    if max_pages > 1 then
        local circle_size = Screen:scaleBySize(14)
        local circle_gap  = Screen:scaleBySize(14)
        local dot_row     = HorizontalGroup:new{ align = "center" }
        for p = 1, max_pages do
            if p > 1 then dot_row[#dot_row+1] = HorizontalSpan:new{ width = circle_gap } end
            local is_active = (p == page)
            -- Active page: filled black circle. Inactive: hollow circle (white + border).
            dot_row[#dot_row+1] = FrameContainer:new{
                bordersize  = Screen:scaleBySize(1),
                radius      = circle_size,
                padding     = 0,
                dimen       = Geom:new{ w = circle_size, h = circle_size },
                background  = is_active and Blitbuffer.COLOR_BLACK or Blitbuffer.COLOR_WHITE,
                -- FrameContainer needs a child — use an empty VerticalGroup.
                VerticalGroup:new{ align = "center" },
            }
        end
        indicator = CenterContainer:new{
            dimen = Geom:new{ w = inner_w, h = circle_size + Screen:scaleBySize(8) },
            dot_row,
        }
    end

    local body = VerticalGroup:new{ align = "left" }
    body[#body+1] = grid
    if indicator then
        body[#body+1] = SH.vspan(Screen:scaleBySize(6), ctx.vspan_pool)
        body[#body+1] = indicator
    end

    return FrameContainer:new{
        bordersize = 0, padding = PAD, padding_top = 0, padding_bottom = 0,
        body,
    }
end

function M.getHeight(ctx)
    local cols    = 3
    local rows    = 2
    local gap     = Screen:scaleBySize(9)
    local inner_w = Screen:getWidth() - PAD * 2
    local cw      = math.floor((inner_w - gap * (cols - 1)) / cols)
    local ch      = math.floor(cw * 1.5)
    local grid_h  = rows * ch + (rows - 1) * gap
    local recent_count = ctx and ctx.recent_fps and #ctx.recent_fps or 0
    local total     = math.min(recent_count, 18)
    local max_pages = math.max(1, math.ceil(total / 6))
    local dot_h = max_pages > 1 and (Screen:scaleBySize(6) + Screen:scaleBySize(22)) or 0
    return Config.getScaledLabelH() + grid_h + dot_h
end


local function _makeScaleItem(ctx_menu)
    local pfx = ctx_menu.pfx
    local _lc = ctx_menu._
    return Config.makeScaleItem({
        text_func    = function() return _lc("Scale") end,
        enabled_func = function() return not Config.isScaleLinked() end,
        title        = _lc("Scale"),
        info         = _lc("Scale for this module.\n100% is the default size."),
        get          = function() return require("sui_config").getModuleScalePct("recent", pfx) end,
        set          = function(v) require("sui_config").setModuleScale(v, "recent", pfx) end,
        refresh      = ctx_menu.refresh,
    })
end

local function _makeThumbScaleItem(ctx_menu)
    local pfx = ctx_menu.pfx
    local _lc = ctx_menu._
    return Config.makeScaleItem({
        text_func = function() return _lc("Cover size") end,
        separator = true,
        title     = _lc("Cover size"),
        info      = _lc("Scale for the cover thumbnails only.\nText and progress bar follow the module scale.\n100% is the default size."),
        get       = function() return require("sui_config").getThumbScalePct("recent", pfx) end,
        set       = function(v) require("sui_config").setThumbScale(v, "recent", pfx) end,
        refresh   = ctx_menu.refresh,
    })
end

function M.getMenuItems(ctx_menu)
    local pfx     = ctx_menu.pfx
    local refresh = ctx_menu.refresh
    local _lc     = ctx_menu._
    local label_item = Config.makeScaleItem({
        text_func = function() return _lc("Text Size") end,
        title     = _lc("Text Size"),
        info      = _lc("Scale for the percentage read text.\n100% is the default size."),
        get       = function() return Config.getItemLabelScalePct("recent", pfx) end,
        set       = function(v) Config.setItemLabelScale(v, "recent", pfx) end,
        refresh   = refresh,
    })
    return {
        _makeScaleItem(ctx_menu),
        label_item,
        Config.makeLabelToggleItem("recent", _("Recent Books"), refresh, _lc),
        _makeThumbScaleItem(ctx_menu),
        {
            text           = _lc("Progress bar"),
            checked_func   = function() return showProgress(pfx) end,
            enabled_func   = function() return not showOverlay(pfx) end,
            keep_menu_open = true,
            callback       = function()
                G_reader_settings:saveSetting(pfx .. SETTING_PROGRESS, not showProgress(pfx))
                refresh()
            end,
        },
        {
            text           = _lc("Percentage text"),
            checked_func   = function() return showText(pfx) end,
            enabled_func   = function() return not showOverlay(pfx) end,
            keep_menu_open = true,
            callback       = function()
                G_reader_settings:saveSetting(pfx .. SETTING_TEXT, not showText(pfx))
                refresh()
            end,
        },
        {
            text           = _lc("Percentage overlay on cover"),
            checked_func   = function() return showOverlay(pfx) end,
            keep_menu_open = true,
            callback       = function()
                G_reader_settings:saveSetting(pfx .. SETTING_OVERLAY, not showOverlay(pfx))
                refresh()
            end,
        },
        {
            text           = _lc("Show finished books"),
            checked_func   = function() return showFinished(pfx) end,
            keep_menu_open = true,
            callback       = function()
                G_reader_settings:saveSetting(pfx .. SETTING_SHOW_FINISHED, not showFinished(pfx))
                refresh()
            end,
        },
    }
end

return M
